#include "CENGFlight.h"
#include "MultiGraph.h"
#include "HashTable.h"
#include <iostream>

int main(int argc, const char* argv[])
{
    // For testing from VPL
    //  ...
    return 0;
}