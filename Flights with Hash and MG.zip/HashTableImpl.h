#ifndef HASH_TABLE_HPP
#define HASH_TABLE_HPP

//=======================//
// Implemented Functions //
//=======================//
template<int MAX_SIZE>
int HashTable<MAX_SIZE>::PRIMES[3] = {102523, 100907, 104659};

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintLine(int tableIndex) const
{
    const HashData& data = table[tableIndex];

    // Using printf here it is easier to format
    if(data.sentinel == SENTINEL_MARK)
    {
        printf("[%03d]         : SENTINEL\n", tableIndex);
    }
    else if(data.sentinel == EMPTY_MARK)
    {
        printf("[%03d]         : EMPTY\n", tableIndex);
    }
    else
    {
        printf("[%03d] - [%03d] : ", tableIndex, data.lruCounter);
        printf("(%-5s) ", data.isCostWeighted ? "True" : "False");
        size_t sz = data.intArray.size();
        for(size_t i = 0; i < sz; i++)
        {
            if(i % 2 == 0)
                printf("[%03d]", data.intArray[i]);
            else
                printf("/%03d/", data.intArray[i]);

            if(i != sz - 1)
                printf("-->");
        }
        printf("\n");
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintTable() const
{
    printf("____________________\n");
    printf("Elements %d\n", elementCount);
    printf("[IDX] - [LRU] | DATA\n");
    printf("____________________\n");
    for(int i = 0; i < MAX_SIZE; i++)
    {
        PrintLine(i);
    }
}

//=======================//
//          TODO         //
//=======================//
template<int MAX_SIZE>
int HashTable<MAX_SIZE>::Hash(int startInt, int endInt, bool isCostWeighted)
{
    /* TODO */
    return PRIMES[0] * startInt + PRIMES[1] * endInt + PRIMES[2] * isCostWeighted;
}
template<int MAX_SIZE>
bool HashTable<MAX_SIZE>::isFull() const{
    if(elementCount > MAX_SIZE/CAPACITY_THRESHOLD) return true;
    return false;
}
template<int MAX_SIZE>
HashTable<MAX_SIZE>::HashTable()
{
    /* TODO */
    for(int i=0;i< MAX_SIZE ; i++){
        table[i].sentinel = EMPTY_MARK;
        table[i].startInt = 0;
        table[i].endInt = 0;
        table[i].lruCounter = 0;
    }
    elementCount=0;
}

template<int MAX_SIZE>
int HashTable<MAX_SIZE>::Insert(const std::vector<int>& intArray, bool isCostWeighted)
{
    /* TODO */
    if (intArray.empty()){
        throw InvalidTableArgException();
    }
    int stint = intArray.front();
    int enint = intArray.back();
    int key = Hash(stint, enint, isCostWeighted);
    int index;
    int i=0;
    for(int k=0 ; k<MAX_SIZE ; k++){
         if(table[k].sentinel == OCCUPIED_MARK && table[k].intArray == intArray and table[k].isCostWeighted == isCostWeighted){
            table[k].lruCounter++;
            return table[k].lruCounter -1;
        }
    }
    while(true){
        index = (key + i * i) % MAX_SIZE;
        if(table[index].sentinel == EMPTY_MARK || table[index].sentinel == SENTINEL_MARK){
            if(elementCount > MAX_SIZE/CAPACITY_THRESHOLD){
                throw TableCapFullException(elementCount);
            }
            table[index].intArray = intArray;
            table[index].sentinel = OCCUPIED_MARK;
            table[index].isCostWeighted = isCostWeighted;
            table[index].startInt = stint;
            table[index].endInt = enint;
            table[index].lruCounter = 1;
            elementCount++;
            return 0;
        }
        i++;
    }
    return -1;
}

template<int MAX_SIZE>
bool HashTable<MAX_SIZE>::Find(std::vector<int>& intArray,
                               int startInt, int endInt, bool isCostWeighted,
                               bool incLRU)
{
    /* TODO */
    int key = Hash(startInt,endInt,isCostWeighted);
    int x=0;
    int index = (key + x*x) % MAX_SIZE;
    while(table[index].sentinel != EMPTY_MARK and table[index].sentinel != SENTINEL_MARK){
        if(table[index].sentinel == OCCUPIED_MARK and table[index].startInt == startInt and table[index].endInt == endInt and table[index].isCostWeighted == isCostWeighted){
            intArray = table[index].intArray;
            if(incLRU){
                table[index].lruCounter++;
            }
            return true;
        }
        x++;
        index = (key + x*x) % MAX_SIZE;
    }
    return false;
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::InvalidateTable()
{
    /* TODO */
    elementCount = 0;
    for(int i=0; i<MAX_SIZE; i++ ){
        if(table[i].sentinel != EMPTY_MARK){
            table[i].intArray.clear();
            table[i].sentinel = EMPTY_MARK;
            table[i].isCostWeighted = false;
            table[i].startInt = 0;
            table[i].endInt = 0; 
            table[i].lruCounter = 0;
        }
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::GetMostInserted(std::vector<int>& intArray) const
{
    /* TODO */
    HashData maxData;
    int maxLru=0;
    for(int i=0 ; i<MAX_SIZE ; i++){
        if(table[i].lruCounter > maxLru){
            maxLru = table[i].lruCounter;
            maxData = table[i];
        }
    }
    intArray = maxData.intArray;
}


template<int MAX_SIZE>
void HashTable<MAX_SIZE>::Remove(std::vector<int>& intArray,
                                 int startInt, int endInt, bool isCostWeighted)
{
    /* TODO */
    int key = Hash(startInt,endInt,isCostWeighted);
    int x=0;
    int index = (key + x*x) % MAX_SIZE;
    while(table[index].sentinel != EMPTY_MARK and table[index].sentinel != SENTINEL_MARK){
        if(table[index].sentinel == OCCUPIED_MARK and table[index].startInt == startInt and table[index].endInt == endInt and table[index].isCostWeighted == isCostWeighted){
            table[index].sentinel = SENTINEL_MARK;
            intArray=table[index].intArray;
            elementCount--;
        }
        x++;
        index = (key + x*x) % MAX_SIZE;
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::RemoveLRU(int lruElementCount)
{
    /* TODO */
    int minLru;
    int minIndex=-1;
    for(int i=0;i < lruElementCount ; i++){
        minLru=100000000;
        for(int j = 0 ; j < MAX_SIZE; j++){
            if(table[j].sentinel == OCCUPIED_MARK and table[j].lruCounter < minLru){
                minLru = table[j].lruCounter;
                minIndex = j;
            }
        }
        table[minIndex].sentinel=SENTINEL_MARK;
        elementCount--;
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintSortedLRUEntries() const
{
    /* TODO */
    std::vector<int> res;
    std::vector<bool> check(MAX_SIZE,false);
    int maxLru;
    int maxIndex=-1;
    for(int i=0;i < elementCount ; i++){
        maxLru=0;
        for(int j = 0 ; j < MAX_SIZE; j++){
            if(table[j].sentinel == OCCUPIED_MARK and table[j].lruCounter > maxLru){
                if(!check[j]){
                    maxLru = table[j].lruCounter;
                    maxIndex = j;
                }
            }
        }
        check[maxIndex]=true;
        res.push_back(maxIndex);
    }
    for(int i=0; i< (int)res.size() ; i++){
        PrintLine(res[i]);
    }
}

#endif // HASH_TABLE_HPP