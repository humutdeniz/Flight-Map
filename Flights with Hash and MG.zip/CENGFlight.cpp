#include "CENGFlight.h"
#include <iostream>

//=======================//
// Implemented Functions //
//=======================//
void CENGFlight::PrintCanNotHalt(const std::string &airportFrom,
                                 const std::string &airportTo,
                                 const std::string &airlineName)
{
    std::cout << "A flight path between \""
              << airportFrom << "\" and \""
              << airportTo << "\" via "
              << airlineName
              << " airlines is not found and cannot be halted"
              << std::endl;
}

void CENGFlight::PrintCanNotResumeFlight(const std::string &airportFrom,
                                         const std::string &airportTo,
                                         const std::string &airlineName)
{
    std::cout << "A flight path between \""
              << airportFrom << "\" and \""
              << airportTo << "\" via "
              << airlineName
              << " airlines cannot be resumed"
              << std::endl;
}

void CENGFlight::PrintFlightFoundInCache(const std::string &airportFrom,
                                         const std::string &airportTo,
                                         bool isCostWeighted)
{
    std::cout << "A flight path between \""
              << airportFrom << "\" and \""
              << airportTo << "\" using "
              << ((isCostWeighted) ? "cost" : "price")
              << " is found in cache." << std::endl;
}

void CENGFlight::PrintFlightCalculated(const std::string &airportFrom,
                                       const std::string &airportTo,
                                       bool isCostWeighted)
{
    std::cout << "A flight path is calculated between \""
              << airportFrom << "\" and \""
              << airportTo << "\" using "
              << ((isCostWeighted) ? "cost" : "price")
              << "." << std::endl;
}

void CENGFlight::PrintPathDontExist(const std::string &airportFrom,
                                    const std::string &airportTo)
{
    std::cout << "A flight path does not exists between \""
              << airportFrom << "\" and \""
              << airportTo << "\"." << std::endl;
}

void CENGFlight::PrintSisterAirlinesDontCover(const std::string &airportFrom)
{
    std::cout << "Could not able to generate sister airline list from \""
              << airportFrom << "\"." << std::endl;
}

void CENGFlight::PrintMap()
{
    navigationMap.PrintEntireGraph();
}

void CENGFlight::PrintCache()
{
    lruTable.PrintTable();
}

CENGFlight::CENGFlight(const std::string &flightMapPath)
    : navigationMap(flightMapPath)
{
}

//=======================//
//          TODO         //
//=======================//
void CENGFlight::HaltFlight(const std::string &airportFrom,
                            const std::string &airportTo,
                            const std::string &airlineName)
{
    /* TODO */
    HaltedFlight newhf;
    newhf.airportFrom = airportFrom;
    newhf.airportTo = airportTo;
    newhf.airline = airlineName;
    std::vector<float> temp = navigationMap.findEdgeWeight(airlineName , airportFrom , airportTo);
    if(temp[0] == -1){
        PrintCanNotHalt(airportFrom , airportTo , airlineName);
        return;
    }
    newhf.w0=temp[0];
    newhf.w1 = temp[1];
    navigationMap.RemoveEdge(airlineName,airportFrom,airportTo);
    haltedFlights.push_back(newhf);
}

// (Direct Function call)
void CENGFlight::ContinueFlight(const std::string &airportFrom,
                                const std::string &airportTo,
                                const std::string &airlineName)
{
    /* TODO */
    for(size_t i=0; i < haltedFlights.size() ; i++){
        if(haltedFlights[i].airportFrom == airportFrom and haltedFlights[i].airportTo == airportTo and haltedFlights[i].airline == airlineName){
            navigationMap.AddEdge(airlineName,airportFrom,airportTo,haltedFlights[i].w0,haltedFlights[i].w1);
            haltedFlights.erase(haltedFlights.begin() + i);
            return;
        }
    }
    PrintCanNotResumeFlight(airportFrom,airportTo,airlineName);
}

void CENGFlight::FindFlight(const std::string &startAirportName,
                            const std::string &endAirportName,
                            float alpha)
{
    /* TODO */
    int ind1 = navigationMap.findIndex(startAirportName);
    int ind2 = navigationMap.findIndex(endAirportName);
    std::vector<int> path;
    bool temp = true;
    if(alpha == 0 or alpha == 1){
        if(alpha == 1){ temp=false;}
        
        if(lruTable.Find(path,ind1,ind2,temp,true)){
            
            PrintFlightFoundInCache(startAirportName,endAirportName,temp);
            navigationMap.PrintPath(path , alpha , true);
        }
        else if(navigationMap.HeuristicShortestPath(path,startAirportName,endAirportName,alpha)){
            
            PrintFlightCalculated(startAirportName , endAirportName , temp);
            if(lruTable.isFull()){
                lruTable.RemoveLRU(1);
            }
            lruTable.Insert(path,temp);
            navigationMap.PrintPath(path , alpha , true);
            
        }
        else{
            PrintPathDontExist( startAirportName , endAirportName );
            return;
        }
    }
    
    else if(navigationMap.HeuristicShortestPath(path,startAirportName,endAirportName,alpha)){
            navigationMap.PrintPath(path , alpha , true);
    }
    else{
	    PrintPathDontExist(startAirportName, endAirportName);
	}
}

void CENGFlight::FindSpecificFlight(const std::string &startAirportName,
                                    const std::string &endAirportName,
                                    float alpha,
                                    const std::vector<std::string> &unwantedAirlineNames) const
{
    /* TODO */
    
    std::vector<int> path;
    navigationMap.FilteredShortestPath(path, startAirportName, endAirportName, alpha, unwantedAirlineNames);
    navigationMap.PrintPath(path, alpha, true);
        
}

int CENGFlight::findMaxNonVisited(std::vector<GraphVertex> vertexList , std::vector<bool> visited) const{
    int minneighbourCnt=0;
    int cnt=0;
    int minIndex=0;
    std::vector<bool> visited2 = visited;
    for(int i = 0 ; i < (int)vertexList.size() ; i++){
        visited2=visited;
        if(visited[i]){
            cnt=0;
            for(int j=0 ; j < (int)vertexList[i].edges.size() ; j++){
                
                if(!visited2[vertexList[i].edges[j].endVertexIndex]){
                    cnt++;
                    visited2[vertexList[i].edges[j].endVertexIndex] = true;
                }
            }
            if(cnt > minneighbourCnt){
                minneighbourCnt = cnt;
                minIndex = i;
            }
        }
    }
    return minIndex;
}
bool CENGFlight::isAllVisited(std::vector<bool> visited) const{
    for(size_t i = 0; i < visited.size() ; i++){
        if(!visited[i]){
            return false;
        }
    }
    return true;
}
std::string CENGFlight::firstNUEdge(std::vector<std::string>& airlineNames, int vertexIndex, std::vector<bool> visited) const{
    
    std::vector<GraphVertex> vertices = navigationMap.getVertexList();
    for(size_t i = 0 ; i < vertices[vertexIndex].edges.size() ; i++){
        if(!navigationMap.in(vertices[vertexIndex].edges[i].name , airlineNames) and !visited[vertices[vertexIndex].edges[i].endVertexIndex]){
            return vertices[vertexIndex].edges[i].name;
        }
    }
    return "";
}
void CENGFlight::FindSisterAirlines(std::vector<std::string>& airlineNames,
                               const std::string& startAirlineName,
                               const std::string& airportName) const
{
    /* TODO */
    std::vector<GraphVertex> vertices = navigationMap.getVertexList();
    std::vector<bool> visited(vertices.size(),false);
    std::vector<bool> prev(vertices.size(),true);
    std::vector<int> q;
    int ind1 = navigationMap.findIndex(airportName);
    q.push_back(ind1);
    visited[ind1]=true;
    int back = 0;
    bool flag=false;
    while (!q.empty()) {
      
        int currInd = q.front();
        q.erase(q.begin());
        for (GraphEdge edge : vertices[currInd].edges) {
            int neighborIndex = edge.endVertexIndex;

            if (edge.name == startAirlineName) {
                flag=true;
                if (!visited[neighborIndex]) {
                    q.push_back(neighborIndex);
                    visited[neighborIndex] = true;
                    back++;
                }
            }
        }
        if(!flag){
            PrintSisterAirlinesDontCover(airportName);
            airlineNames.clear();
            return;}
    }
    airlineNames.push_back(startAirlineName);
    while(!isAllVisited(visited)){
        int temp = findMaxNonVisited(vertices , visited);
        std::string edgeName = firstNUEdge(airlineNames, temp, visited);
        if(edgeName=="") PrintSisterAirlinesDontCover(airportName);
        q.clear();
        q.push_back(temp);
        flag=false;
        visited[temp] = true;
        back=0;
        if(prev == visited){
            PrintSisterAirlinesDontCover(airportName);
            airlineNames.clear();
            return;
        }
        prev=visited;
        airlineNames.push_back(edgeName);
        while (!q.empty()) {
          
            int currInd = q.front();
            q.erase(q.begin());
            for (GraphEdge edge : vertices[currInd].edges) {
                int neighborIndex = edge.endVertexIndex;
                if (navigationMap.in(edge.name,airlineNames) and !visited[neighborIndex]) {
                    flag=true;
                    q.push_back(neighborIndex);
                    visited[neighborIndex] = true;
                    back++;
                    
                }
            }
            if(!flag){
                PrintSisterAirlinesDontCover(airportName);
                airlineNames.clear();
                return;    
            }
        }
        
    }
    airlineNames.erase(airlineNames.begin());
}

int CENGFlight::FurthestTransferViaAirline(const std::string &airportName,
                                           const std::string &airlineName) const
{
    /* TODO */
    std::vector<GraphVertex> vertices = navigationMap.getVertexList();
    bool flag=false;
    for(size_t i = 0 ; i < vertices.size() ; i++){
        if(vertices[i].name == airportName){
            flag=true;
        }
    }
    if(!flag) return -1;
    return navigationMap.MaxDepthViaEdgeName(airportName,airlineName);
}